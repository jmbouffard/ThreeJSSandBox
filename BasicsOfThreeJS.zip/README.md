# BasicsOfThreeJS
Basics of Three.js

My changes to Ilmari Heikkinen's [great slide presentation](http://fhtr.org/BasicsOfThreeJS). The main changes are to the first two thirds, where I start with a three.js example and modify it, with code samples shown along the way. [Here's my slideset](http://www.realtimerendering.com/basics3js).
